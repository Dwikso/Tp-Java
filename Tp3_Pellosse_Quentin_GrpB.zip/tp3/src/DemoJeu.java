/**
 * Classe DemoJeu
 *
 * @author Pellosse Quentin
 * @version 1.0
 *
 */

public class DemoJeu {
  /**
   * Méthode main
   * 
   * @param args
   */
  public static void main(String[] args) {
    // Création d'un jeu
    Jeu jeu = new Jeu();
    // Affichage du jeu
    jeu.afficher();
  }
}
